import './bootstrap';
import $ from 'jquery';
import Swal from 'sweetalert2';
window.$ = window.jQuery = $;
