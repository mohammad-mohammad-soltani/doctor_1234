<div style="width: 100%; height: {{$space}}" >
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
</div>
