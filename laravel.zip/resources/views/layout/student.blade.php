@include('layout.header_s')
@include('layout.footer_s')
