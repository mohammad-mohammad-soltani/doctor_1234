@vite('resources/js/app.js')
@vite('resources/js/student.js')

    <div style="transform: translateY(122%)" id="alert_dialog"  class="alert">
        <div class="icon">
            <i class="fa-solid  fa-check" ></i>
        </div>
        <div class="text_alert">
            <span>فلان عمل با موفقیت انجام شد</span>
        </div>
    </div>
    <div class="loading-box">
        <h1 class="kalame-bold" >درحال بارگذاری</h1>
        <span class="thin-text" >لطفا تا بارگذاری کامل منتظر بمانید</span>
        <x-spacer space="20px" />
        <ul class="wave-menu">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
        <span class="flex-end-c thin-text" >سامانه آموزشی شتاب - واحد پویش دبیرستان سادات دوره اول</span>
    </div>

{{--    <div class="body-light">--}}

{{--    </div>--}}
</body>
</html>
