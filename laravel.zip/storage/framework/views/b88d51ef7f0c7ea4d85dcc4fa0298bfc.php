<?php $__env->startSection('content'); ?>
    <style>
        .content{
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
    <div class="main_form">
        <div class="inner_form_box">
            <h2>اطلاعات حساب کاربری</h2>
            <span class="thin-text" >شما میتوانید اطلاعات غیر ضروری خود را ویرایش کنید</span>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '20px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '20px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <div class="line_form_items">
                <label  class="thin-text" for="name">نام و نام خانوادگی</label>
                <input autocomplete="off" class="simple-border-input thin-text en " placeholder="نام کاربری خود را وارد نمایید"  type="text" name="username" id="name" value="<?php echo e($user -> name); ?>">
            </div>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '20px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '20px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <div class="line_form_items">
                <label  class="thin-text" for="username">نام کاربری</label>
                <input autocomplete="off"  class="simple-border-input thin-text en " placeholder="نام کاربری خود را وارد نمایید"  type="text" name="username" id="username" value="<?php echo e($user -> username); ?>">
            </div>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '20px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '20px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <div class="line_form_items">
                <label  class="thin-text" for="password">کلمه عبور</label>
                <input autocomplete="off" class="simple-border-input thin-text en" placeholder="کلمه عبور جدید خود را وارد نمایید"  type="text" name="password" id="password">
            </div>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <button id="manager_settings" class="send-btn" >ذخیره تغییرات </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/manager/settings.blade.php ENDPATH**/ ?>