<?php echo $__env->make('layout.header_s', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.footer_s', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/layout/student.blade.php ENDPATH**/ ?>