<?php
    if(\Illuminate\Support\Facades\Auth::guard('manager') -> check()){
        $guard = 'manager';
        $user = \Illuminate\Support\Facades\Auth::guard('manager')->getUser();
    }
    if(\Illuminate\Support\Facades\Auth::guard('origin') -> check()){
        $guard = 'origin';
        $user = \Illuminate\Support\Facades\Auth::guard('origin')->getUser();
    }
    if(\Illuminate\Support\Facades\Auth::guard('doctor') -> check()){
        $guard = 'doctor';
        $user = \Illuminate\Support\Facades\Auth::guard('doctor')->getUser();
    }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> -سامانه مد لاین</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="/font/yekan/yekan.css">
    <link rel="stylesheet" href="/font/kalame/kalame.css">
    <link rel="stylesheet" href="/font/font-awsem/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/theme_st.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('date-picker/style.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('date-picker/script.js')); ?>"></script>
</head>
<body>

<header>

    <div class="items">

        <div class="profile" id="profile-btn">
            <div class="avatar"  >
                <img src="" alt="">
            </div>
            <span class="display_name" ><?php echo e($user -> name); ?></span>



        </div>
        <div id="profile_box" style="display: none"  class="profile_box ">
            <span class="thin-text kalame-bold" > سلام <?php echo e($user -> name); ?> </span>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '10px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '10px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <div class="profile-box-menu">
                <?php if($guard == 'doctor'): ?>
                    <a href="<?php echo e(route('doctor.logout')); ?>" class="send-btn">خروج از حساب کاربری</a>
                <?php elseif($guard == 'origin'): ?>
                    <a href="<?php echo e(route('origin.logout')); ?>" class="send-btn">خروج از حساب کاربری</a>
                <?php elseif($guard == 'manager'): ?>
                    <a href="<?php echo e(route('manager.logout')); ?>" class="send-btn">خروج از حساب کاربری</a>
                <?php endif; ?>
            </div>

        </div>

    </div>
    <div class="search">
        <div class="search_box">
            <div class="icon">
                <i class="fa-solid fa-magnifying-glass"></i>
            </div>
            <input type="text" placeholder="دنبال چی میگردی" >
        </div>
    </div>
    <div class="logo">
        <h1 class="kalame-bold rtl" >Med Line</h1>
    </div>
    <div class="open-sidebar">
        <button id="open-sidebar-btn" ><i class="fa-solid fa-bars"></i></button>
    </div>
</header>
<div  class="side_bar">
    <ul class="main" >
        <?php if($guard == 'manager'): ?>
            <li class="">
                <a href="<?php echo e(route("manager.dashboard")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-eye"></i>
                    </div>
                    <span>داشبورد</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("manager.add_client")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن حساب های کاربری</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("manager.products")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن محصولات</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("manager.clinic")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-list"></i>
                    </div>
                    <span>مدیریت کلینیک ها</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("manager.category")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن دسته بندی</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("manager.settings")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-dashboard"></i>
                    </div>
                    <span>تنظیمات حساب کاربری</span>
                </a>
            </li>
        <?php elseif($guard === "origin"): ?>
            <li class="">
                <a href="<?php echo e(route("origin.products")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن محصولات</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("origin.calendar")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن نوبت</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("origin.category")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>افزودن دسته بندی</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("origin.settings")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-dashboard"></i>
                    </div>
                    <span>تنظیمات حساب کاربری</span>
                </a>
            </li>








        <?php elseif($guard === "doctor"): ?>
            <li class="">
                <a href="<?php echo e(route("doctor.dashboard")); ?>">
                    <div class="icon">
                        <i class="fa-solid fa-add"></i>
                    </div>
                    <span>داشبورد</span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo e(route("doctor.settings")); ?>/">
                    <div class="icon">
                        <i class="fa-solid fa-dashboard"></i>
                    </div>
                    <span>تنظیمات حساب کاربری</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <div class="mobile-only side_bar_mobile_zone" style="display: none" >
        <nav  >
            <button>خروج از حساب</button>

            <button id="close-sidebar" >بستن</button>
        </nav>
        <ul class="" >

            <?php if($guard == 'manager'): ?>
                <li class="">
                    <a href="<?php echo e(route("manager.dashboard")); ?>/">
                        <div class="icon">
                            <i class="fa-solid fa-eye"></i>
                        </div>
                        <span>داشبورد</span>
                    </a>
                </li>








            <?php endif; ?>

        </ul>
    </div>
</div>
<div class="end-side-bar" style="grid-area: end-side-bar">

</div>
<div class="top_sidebar">
    <img class="shetab_logo" src="/images/logo.png" alt="">
</div>
<div class="content">
<?php echo $__env->yieldContent('content'); ?>
</div>
<?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/layout/header_s.blade.php ENDPATH**/ ?>