<?php
    function get_clinic_name($id){
        switch( $id){
            case "all":
                return "همه";
            default :
                try{return \App\Models\Clinic::where('id' , $id)->get()->first()->name;}catch (Exception $exeption) {return "کلینیک حذف شده";}

        }

    }
?>

<?php $__env->startSection('title' , 'افزودن کلینیک'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <h1 class="kalame-black text-2xl" > افزودن دسته بندی</h1>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <section class="add-clinic">
        <div class="line_1">
            <label class="kalame-bold" for="">نام دسته بندی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input id="product_name" type="text" class="simple-border-input w-full ">
        </div>
        <div class="line_2">
            <button id="new_category" class="send-btn" >افزودن دسته بندی</button>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <h1 class="kalame-black text-2xl" >لیست دسته بندی ها</h1>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <div class="table" >
        <div class="line head">
            <div class="id">#</div>
            <div class="name">نام محصول</div>
            <div class="name">کلینیک</div>
            <div class="actions">فعالیت ها</div>
        </div>
        <?php $__currentLoopData = \App\Models\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="col_<?php echo e($clinic -> id); ?>" class="line"  >
                <div class="id"><?php echo e($clinic -> id); ?></div>
                <div class="name"><?php echo e($clinic -> name); ?></div>
                <div class="name"><?php echo e(get_clinic_name($clinic -> clinic)); ?></div>
                <div class="actions">
                    <button  class="actions-btn" data-id="<?php echo e($clinic -> id); ?>"  >فعالیت ها</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <section style="display: none" id="actions_popup" class="pop_up">
        <section class="actions-pop">

            <h2 class="kalame-bold" >فعالیت ها</h2>
            <p>شما از اینجا میتوانید فعالیت های مربوط به کالاها / خدمات را انجام دهید</p>
            <div class="actions " style="width: 100%">
                <button id="delete_category" class=" button full" >حذف کالا / خدمت</button>

            </div>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <button class="close-btn send-btn" data-close="actions_popup">بستن</button>
        </section>

    </section>


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/manager/clinic/category.blade.php ENDPATH**/ ?>