<div style="width: 100%; height: <?php echo e($space); ?>" >
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
</div>
<?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/components/spacer.blade.php ENDPATH**/ ?>