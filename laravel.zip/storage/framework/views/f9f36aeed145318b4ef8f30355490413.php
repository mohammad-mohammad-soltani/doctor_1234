<?php
    function get_clinic_name($id){
        switch( $id){
            case "all":
                return "همه";
            default :
                return \App\Models\Clinic::where('id' , $id)->get()->first()->name;
        }

    }

?>

<?php $__env->startSection('title' , 'افزودن کلینیک'); ?>
<?php $__env->startSection('content'); ?>
    <meta data-id="<?php echo e($recorde -> id); ?>" id="calendar_id" >
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <h1 class="kalame-black text-2xl" > ویرایش نوبت</h1>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <section class="add-clinic">
        <div class="line_1">
            <label class="kalame-bold" for="">نام مراجعه کننده</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" id="ref_name" value="<?php echo e($recorde -> name); ?>"  type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold" for="">لاین خدماتی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <select autocomplete="off" name="" id="product_line" class="simple-border-input w-full" id="" >
                <?php $__currentLoopData = \App\Models\Category::where('clinic' ,  Auth::guard('origin') -> user() -> clinic_id) -> orWhere('clinic' , 'all') -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($recorde -> product_line == $product -> id): ?> selected="1" <?php endif; ?> value="<?php echo e($product -> id); ?>"><?php echo e($product -> name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold" for="">نوع کالای مصرفی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <select autocomplete="off" name="" id="product_type" class="simple-border-input w-full" id="" >
                <?php $__currentLoopData = \App\Models\Products::where('clinic' ,  Auth::guard('origin') -> user() -> clinic_id) -> orWhere('clinic' , 'all') -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if(json_decode($recorde -> requirements , true)['product'] == $product -> id): ?> selected="1" <?php endif; ?> value="<?php echo e($product -> id); ?>"><?php echo e($product -> name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold" for="">مقدار مصرفی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e(json_decode($recorde -> requirements , true)['val']); ?>" id="product_val" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">طریقه پرداخت</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <select autocomplete="off"  id="payment_way" class="simple-border-input w-full" >
                <option  <?php if($recorde -> payment_way == 1): ?> selected <?php endif; ?>  value="1">نقدی</option>
                <option <?php if($recorde -> payment_way == 2): ?> selected <?php endif; ?> value="2">کارت به کارت</option>
                <option <?php if($recorde -> payment_way == 3): ?> selected <?php endif; ?> value="3">کارتخوان</option>
            </select>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>

            <label class="kalame-bold" for="">طریقه آشنایی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e($recorde -> introduce_way); ?>" id="introduce_way" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
        </div>
        <div class="line_2" >
            <label class="kalame-bold text-right w-full" for=""  >تاریخ مراجعه</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" id="coming_time" data-jdp data-jdf-time value="<?php echo e($recorde -> time); ?>"  type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">شماره پرونده</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e($recorde -> number); ?>" id="serial_number" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">نام پزشک</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <select autocomplete="off" id="doctor_name" class="simple-border-input w-full" >
                <?php $__currentLoopData = \App\Models\Doctor::where('clinic_id' , Auth::guard('origin') -> user() -> clinic_id) -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($doctor -> id == $recorde -> $doctor): ?> selected <?php endif; ?> value="<?php echo e($doctor -> id); ?>"><?php echo e($doctor -> name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">هزینه جانبی</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e($recorde -> price); ?>" id="other_prices" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">زمان صرف شده جهت انجام</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e($recorde -> timeofwork); ?>" id="timeofwork" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <label class="kalame-bold text-right w-full" for="">هزینه دریافت شده</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input autocomplete="off" value="<?php echo e($recorde -> payment_status); ?>" id="goted_money" type="text" class="simple-border-input w-full ">
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <button id="edite_calendar" class="send-btn" >ویرایش نوبت</button>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/origin/clinic/calendar-edite.blade.php ENDPATH**/ ?>