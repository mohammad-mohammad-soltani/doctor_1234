<?php $__env->startSection('title' , 'افزودن کلینیک'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <h1 class="kalame-black text-2xl" > افزودن کلینیک</h1>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <section class="add-clinic">
        <div class="line_1">
            <label class="kalame-bold" for="">نام کلینیک</label>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <input id="clinic_name" type="text" class="simple-border-input w-full ">
        </div>
        <div class="line_2">
            <button id="new_clinic" class="send-btn" >افزودن کلینیک</button>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <h1 class="kalame-black text-2xl" >لیست کلینیک ها</h1>
    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
    <div class="table" >
        <div class="line head">
            <div class="id">#</div>
            <div class="name">نام کلینیک</div>
            <div class="actions">فعالیت ها</div>
        </div>
        <?php $__currentLoopData = \App\Models\Clinic::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="line"  >
                <div class="id"><?php echo e($clinic -> id); ?></div>
                <div class="name"><?php echo e($clinic -> name); ?></div>
                <div class="actions">
                    <button  class="actions-btn" data-id="<?php echo e($clinic -> id); ?>"  >فعالیت ها</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <section style="display: none" id="actions_popup" class="pop_up">
        <section class="actions-pop">

            <h2 class="kalame-bold" >فعالیت ها</h2>
            <p>شما از اینجا میتوانید فعالیت های مربوط به کلینیک ها را انجام دهید</p>
            <div class="actions " style="width: 100%">
                <button id="add_doctor_btn" class="add_doctor button" >افزودن پزشک</button>
                <button id="add_origin_btn" class="add_origin button" >افزودن منشی</button>
                <button id="add_origin_btn" class="add_origin button full" >مدیریت کلینیک</button>

            </div>
            <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
            <button class="close-btn send-btn" data-close="actions_popup">بستن</button>
        </section>

    </section>

    <section class="pop_up" id="add_doctor" style="display: none">
        <section class="add-clinic ">
            <div class="line_1">
                <label class="kalame-bold" for="">نام پزشک</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="doctor_name" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <label class="kalame-bold" for="">کلمه عبور</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="doctor_password" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <button data-close="add_doctor" class="send-btn desk-close close-btn" >بستن</button>

            </div>
            <div class="line_2">
                <label  class="kalame-bold w-full" for="">نام کاربری</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="doctor_username" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <button id="new_doctor" class="send-btn" >افزودن پزشک</button>
                <div class="mobile-only" style="display: none">
                    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.7rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.7rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                </div>
                <button data-close="add_doctor"  class="close-btn send-btn mobile-only" style="display: none" >بستن</button>

            </div>

        </section>
    </section>
    <section class="pop_up" id="add_origin" style="display: none">
        <section class="add-clinic ">
            <div class="line_1">
                <label class="kalame-bold" for="">نام منشی</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="origin_name" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <label class="kalame-bold" for="">کلمه عبور</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="origin_password" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <button data-close="add_origin" class="send-btn desk-close close-btn" >بستن</button>

            </div>
            <div class="line_2">
                <label  class="kalame-bold w-full" for="">نام کاربری</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <input id="origin_username" type="text" class="simple-border-input w-full ">
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <label  class="kalame-bold w-full" for="">پزشک منشی</label>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <select id="origin_doctor" type="text" class="simple-border-input w-full ">

                </select>
                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.5rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '1rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '1rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                <button id="new_origin" class="send-btn" >افزودن منشی</button>
                <div class="mobile-only" style="display: none">
                    <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '0.7rem']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '0.7rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
                </div>
                <button data-close="add_origin"  class="close-btn send-btn mobile-only" style="display: none" >بستن</button>
            </div>

        </section>
    </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/manager/clinic/add.blade.php ENDPATH**/ ?>