<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/student.js'); ?>

    <div style="transform: translateY(122%)" id="alert_dialog"  class="alert">
        <div class="icon">
            <i class="fa-solid  fa-check" ></i>
        </div>
        <div class="text_alert">
            <span>فلان عمل با موفقیت انجام شد</span>
        </div>
    </div>
    <div class="loading-box">
        <h1 class="kalame-bold" >درحال بارگذاری</h1>
        <span class="thin-text" >لطفا تا بارگذاری کامل منتظر بمانید</span>
        <?php if (isset($component)) { $__componentOriginal1a8dded40c50f81d735e09121138f164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a8dded40c50f81d735e09121138f164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spacer','data' => ['space' => '20px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => '20px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $attributes = $__attributesOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__attributesOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a8dded40c50f81d735e09121138f164)): ?>
<?php $component = $__componentOriginal1a8dded40c50f81d735e09121138f164; ?>
<?php unset($__componentOriginal1a8dded40c50f81d735e09121138f164); ?>
<?php endif; ?>
        <ul class="wave-menu">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
        <span class="flex-end-c thin-text" >سامانه آموزشی شتاب - واحد پویش دبیرستان سادات دوره اول</span>
    </div>




</body>
</html>
<?php /**PATH /home/mohammad/Desktop/doctor_panel/resources/views/layout/footer_s.blade.php ENDPATH**/ ?>