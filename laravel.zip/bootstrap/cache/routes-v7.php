<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G7maD4CFvb8CdeAL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'manager.login_post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/add_client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.add_client',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/doctors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.doctors',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/origins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.origins',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/clinic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.clinic',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.category',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/update_clinic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.update_clinic',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/add_clinic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q9phMJriww25HrGp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/add_doctor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TfXPUxkuAbNCdtnF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/add_origin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nG5vxU2MOD7tBVxT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/delete_product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vBwkw4og1Q7uq6v0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/delete_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dtvgkPf77r5Vu6Bl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/delete_clinic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qg8eyzlHlVXd5Hdk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/add_product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V2W3Ii74x9kNNr6t',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/get_origins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6zjrQaoMikViwbiB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/get_doctor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vc6ePNfgtNontFQT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/get_origin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6Dvy29SNw9J40arS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/delete_doctor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h5ZDHl3X6M6qZb0N',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/edite_doctor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qkrxFfJbBpA1eE3p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/edite_origin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X4WFMNTey4CVw6jk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/delete_origin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U3Nz1IMzO2iFFxhC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Manager/api/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FykShEIBSsPOuyip',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'origin.login_post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.calendar',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.category',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/add_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BRfK0YOQ1JLIFaQM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/delete_product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::22SMv8z2WfXkm8He',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/add_product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C5YN3fdOURx2vTEp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/add_calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hjebi1wyDXAZJvQ7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/edite_calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0cPOKkZAPydFlvcM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/delete_calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TgliUKnqOWx4Nwjx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/delete_category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TfwLJHJRCW2vU6mq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Receptionist/api/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OjbFczNSYOyFmZJM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.login_post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/api/edite_calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QW4pBmE4y1thOrQF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/api/delete_calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hkm4CNqGkW3mafXk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Doctor/api/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oeQuhQGzPr0IhGIh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/Manager/clinic/([^/]++)(*:31)|/Receptionist/calendar/([^/]++)(*:69)|/Doctor/calendar/([^/]++)(*:101)|/storage/(.*)(*:122))/?$}sDu',
    ),
    3 => 
    array (
      31 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'manager.clinic_2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      69 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'origin.calendar_edite',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'doctor.calendar_edite',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      122 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::G7maD4CFvb8CdeAL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:829:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'/home/mohammad/Desktop/doctor_panel/vendor/laravel/framework/src/Illuminate/Foundation/Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000003250000000000000000";}}',
        'as' => 'generated::G7maD4CFvb8CdeAL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@login',
        'controller' => 'App\\Http\\Controllers\\Manager@login',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.login_post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@login_post',
        'controller' => 'App\\Http\\Controllers\\Manager@login_post',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.login_post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@panel',
        'controller' => 'App\\Http\\Controllers\\Manager@panel',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.add_client' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/add_client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_client',
        'controller' => 'App\\Http\\Controllers\\Manager@add_client',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.add_client',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@products',
        'controller' => 'App\\Http\\Controllers\\Manager@products',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.doctors' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/doctors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_client',
        'controller' => 'App\\Http\\Controllers\\Manager@add_client',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.doctors',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.origins' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/origins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_client',
        'controller' => 'App\\Http\\Controllers\\Manager@add_client',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.origins',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@settings',
        'controller' => 'App\\Http\\Controllers\\Manager@settings',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.settings',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.clinic' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/clinic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@clinic',
        'controller' => 'App\\Http\\Controllers\\Manager@clinic',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.clinic',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.clinic_2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/clinic/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@clinic2',
        'controller' => 'App\\Http\\Controllers\\Manager@clinic2',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.clinic_2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.category' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@category',
        'controller' => 'App\\Http\\Controllers\\Manager@category',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.category',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@logout',
        'controller' => 'App\\Http\\Controllers\\Manager@logout',
        'namespace' => NULL,
        'prefix' => '/Manager',
        'where' => 
        array (
        ),
        'as' => 'manager.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'manager.update_clinic' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/update_clinic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@update_clinic',
        'controller' => 'App\\Http\\Controllers\\Manager@update_clinic',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'manager.update_clinic',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q9phMJriww25HrGp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/add_clinic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_clinic',
        'controller' => 'App\\Http\\Controllers\\Manager@add_clinic',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::q9phMJriww25HrGp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TfXPUxkuAbNCdtnF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/add_doctor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_doctor',
        'controller' => 'App\\Http\\Controllers\\Manager@add_doctor',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::TfXPUxkuAbNCdtnF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nG5vxU2MOD7tBVxT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/add_origin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_origin',
        'controller' => 'App\\Http\\Controllers\\Manager@add_origin',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::nG5vxU2MOD7tBVxT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vBwkw4og1Q7uq6v0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/delete_product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_product',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_product',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::vBwkw4og1Q7uq6v0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dtvgkPf77r5Vu6Bl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/delete_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_category',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_category',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::dtvgkPf77r5Vu6Bl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qg8eyzlHlVXd5Hdk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/delete_clinic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_clinic',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_clinic',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::qg8eyzlHlVXd5Hdk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V2W3Ii74x9kNNr6t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/add_product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@add_product',
        'controller' => 'App\\Http\\Controllers\\Manager@add_product',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::V2W3Ii74x9kNNr6t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6zjrQaoMikViwbiB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/api/get_origins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@get_origins',
        'controller' => 'App\\Http\\Controllers\\Manager@get_origins',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::6zjrQaoMikViwbiB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vc6ePNfgtNontFQT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/api/get_doctor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@get_doctor',
        'controller' => 'App\\Http\\Controllers\\Manager@get_doctor',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::vc6ePNfgtNontFQT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6Dvy29SNw9J40arS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Manager/api/get_origin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@get_origin',
        'controller' => 'App\\Http\\Controllers\\Manager@get_origin',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::6Dvy29SNw9J40arS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h5ZDHl3X6M6qZb0N' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/delete_doctor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_doctor',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_doctor',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::h5ZDHl3X6M6qZb0N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qkrxFfJbBpA1eE3p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/edite_doctor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@edite_doctor',
        'controller' => 'App\\Http\\Controllers\\Manager@edite_doctor',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::qkrxFfJbBpA1eE3p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X4WFMNTey4CVw6jk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/edite_origin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@edite_origin',
        'controller' => 'App\\Http\\Controllers\\Manager@edite_origin',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::X4WFMNTey4CVw6jk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U3Nz1IMzO2iFFxhC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/delete_origin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_origin',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_origin',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::U3Nz1IMzO2iFFxhC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FykShEIBSsPOuyip' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Manager/api/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\ManagerAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@manager_settings',
        'controller' => 'App\\Http\\Controllers\\Manager@manager_settings',
        'namespace' => NULL,
        'prefix' => 'Manager/api',
        'where' => 
        array (
        ),
        'as' => 'generated::FykShEIBSsPOuyip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@login',
        'controller' => 'App\\Http\\Controllers\\Origin@login',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.login_post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@login_post',
        'controller' => 'App\\Http\\Controllers\\Origin@login_post',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.login_post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@panel',
        'controller' => 'App\\Http\\Controllers\\Origin@panel',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@products',
        'controller' => 'App\\Http\\Controllers\\Origin@products',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.calendar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@calendar',
        'controller' => 'App\\Http\\Controllers\\Origin@calendar',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.calendar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.calendar_edite' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/calendar/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@calendar_edite',
        'controller' => 'App\\Http\\Controllers\\Origin@calendar_edite',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.calendar_edite',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.category' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@category',
        'controller' => 'App\\Http\\Controllers\\Origin@category',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.category',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@logout',
        'controller' => 'App\\Http\\Controllers\\Origin@logout',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'origin.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Receptionist/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@settings',
        'controller' => 'App\\Http\\Controllers\\Origin@settings',
        'namespace' => NULL,
        'prefix' => '/Receptionist',
        'where' => 
        array (
        ),
        'as' => 'origin.settings',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BRfK0YOQ1JLIFaQM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/add_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@add_category',
        'controller' => 'App\\Http\\Controllers\\Origin@add_category',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::BRfK0YOQ1JLIFaQM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::22SMv8z2WfXkm8He' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/delete_product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@delete_product',
        'controller' => 'App\\Http\\Controllers\\Origin@delete_product',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::22SMv8z2WfXkm8He',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C5YN3fdOURx2vTEp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/add_product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@add_product',
        'controller' => 'App\\Http\\Controllers\\Origin@add_product',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::C5YN3fdOURx2vTEp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hjebi1wyDXAZJvQ7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/add_calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@add_calendar',
        'controller' => 'App\\Http\\Controllers\\Origin@add_calendar',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::hjebi1wyDXAZJvQ7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0cPOKkZAPydFlvcM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/edite_calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@edite_calendar',
        'controller' => 'App\\Http\\Controllers\\Origin@edite_calendar',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::0cPOKkZAPydFlvcM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TgliUKnqOWx4Nwjx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/delete_calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@delete_calendar',
        'controller' => 'App\\Http\\Controllers\\Origin@delete_calendar',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::TgliUKnqOWx4Nwjx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TfwLJHJRCW2vU6mq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/delete_category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Manager@delete_category',
        'controller' => 'App\\Http\\Controllers\\Manager@delete_category',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::TfwLJHJRCW2vU6mq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OjbFczNSYOyFmZJM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Receptionist/api/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\OriginAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Origin@origin_settings',
        'controller' => 'App\\Http\\Controllers\\Origin@origin_settings',
        'namespace' => NULL,
        'prefix' => 'Receptionist/api',
        'where' => 
        array (
        ),
        'as' => 'generated::OjbFczNSYOyFmZJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Doctor/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@login',
        'controller' => 'App\\Http\\Controllers\\Doctor@login',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.login_post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Doctor/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@login_post',
        'controller' => 'App\\Http\\Controllers\\Doctor@login_post',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.login_post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.calendar_edite' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Doctor/calendar/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@calendar_edite',
        'controller' => 'App\\Http\\Controllers\\Doctor@calendar_edite',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.calendar_edite',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Doctor/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@logout',
        'controller' => 'App\\Http\\Controllers\\Doctor@logout',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Doctor/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@settings',
        'controller' => 'App\\Http\\Controllers\\Doctor@settings',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.settings',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'doctor.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Doctor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DoctorAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@panel',
        'controller' => 'App\\Http\\Controllers\\Doctor@panel',
        'namespace' => NULL,
        'prefix' => '/Doctor',
        'where' => 
        array (
        ),
        'as' => 'doctor.dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QW4pBmE4y1thOrQF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Doctor/api/edite_calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DoctorAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@edite_calendar',
        'controller' => 'App\\Http\\Controllers\\Doctor@edite_calendar',
        'namespace' => NULL,
        'prefix' => 'Doctor/api',
        'where' => 
        array (
        ),
        'as' => 'generated::QW4pBmE4y1thOrQF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hkm4CNqGkW3mafXk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Doctor/api/delete_calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DoctorAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@delete_calendar',
        'controller' => 'App\\Http\\Controllers\\Doctor@delete_calendar',
        'namespace' => NULL,
        'prefix' => 'Doctor/api',
        'where' => 
        array (
        ),
        'as' => 'generated::hkm4CNqGkW3mafXk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oeQuhQGzPr0IhGIh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'Doctor/api/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\DoctorAuth',
        ),
        'uses' => 'App\\Http\\Controllers\\Doctor@doctor_settings',
        'controller' => 'App\\Http\\Controllers\\Doctor@doctor_settings',
        'namespace' => NULL,
        'prefix' => 'Doctor/api',
        'where' => 
        array (
        ),
        'as' => 'generated::oeQuhQGzPr0IhGIh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user.logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:158:"function () {
    \\Auth::guard(\'doctor\')->logout();
    \\Auth::guard(\'manager\')->logout();
    \\Auth::guard(\'origin\')->logout();

    return \\redirect("/");
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000031d0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'user.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:55:"/home/mohammad/Desktop/doctor_panel/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000003570000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
